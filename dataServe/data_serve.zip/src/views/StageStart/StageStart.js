export default {
  name: 'StageStart',
  data () {
    return {}
  },
  mounted () {},
  created () {},
  methods: {},
  watch: {}
}
