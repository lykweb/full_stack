<template>
  <div class="content">
    <div class="stage-level">
      <div class="stage-item stage-start"><span class="stage-start-text">入学阶段</span></div>
      <div class="stage-item stage-progress"><span class="stage-progress-text">校内学习阶段</span></div>
      <div class="stage-item stage-end"><span class="stage-end-text">毕业、就业阶段</span></div>
    </div>
    <div class="behavior">
      <div class="behavior-start">
        <div class="behavior-title behavior-start-title">新生入学</div>
        <div class="behavior-content">
          <svg version="1.1"
            baseProfile="full"
            width="100%" height="806"
            xmlns="http://www.w3.org/2000/svg">

            <image href="../../assets/img/png/9.png" x="0" y="0" height="122px" width="122px"></image>
            <foreignObject x="46" y="40" height="42" width="30">
              <div xmlns="http://www.w3.org/1999/xhtml" style="font-size: 15px; color: #fff;">学习行为</div>
            </foreignObject>
            <path d="M 61 100 V 162 H 105 M 61 162 V 398 H 105 M 61 398 V 474 H 105 M 61 474 V 550 H 105" fill="transparent" stroke="rgba(64,98,255, 0.5)" />
            <path d="M 105 162 Q 105 146 121 146 H 173 Q 189 146 189 162 189 178 173 178 H 121 Q 105 178 105 162" stroke="transparent" fill="rgba(64,98,255, 1)" />
            <path d="M 147 178 V 183 M 147 188 V 193 M 147 198 V 203 M 147 208 V 213 M 147 218 H 167 M 147 218 V 223 M 147 228 V 233 M 147 238 V 243 M 147 248 V 253 M 147 258 H 167 M 147 258 V 263 M 147 268 V 273 " fill="transparent" stroke="rgba(64,98,255, 0.5)" />
          </svg>
        </div>
      </div>
      <div class="behavior-progress">
        <div class="behavior-progress-item">
          <div class="behavior-title behavior-progress-title">2019-2020</div>
        </div>
      </div>
      <div class="behavior-end">
        <div class="behavior-title behavior-end-title">毕业后方向</div>
      </div>
    </div>
  </div>
</template>

<script src="./StudentBehaviorMap"></script>
<style src="./StudentBehaviorMap.less" lang="less" scoped></style>
