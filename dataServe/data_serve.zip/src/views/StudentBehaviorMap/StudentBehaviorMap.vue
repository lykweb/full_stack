<template>
  <div class="content">
    <div class="stage-level">
      <div class="stage-item stage-start"><span class="stage-start-text">入学阶段</span></div>
      <div class="stage-item stage-progress"><span class="stage-progress-text">校内学习阶段</span></div>
      <div class="stage-item stage-end"><span class="stage-end-text">毕业、就业阶段</span></div>
    </div>
  </div>
</template>

<script src="./StudentBehaviorMap"></script>
<style src="./StudentBehaviorMap.less" lang="less" scoped></style>
