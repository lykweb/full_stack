export default {
  name: 'StudentBehaviorMap',
  data () {
    return {}
  },
  mounted () {},
  created () {},
  methods: {},
  watch: {}
}
