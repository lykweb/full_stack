<template>
  <div id="app">
    <nav>
      <router-link to="/">behavioralMap</router-link>
    </nav>
    <div class="flex-item">
      <router-view/>
    </div>
  </div>
</template>

<style lang="less">
#app {
  color: #2c3e50;
  display: flex;
}

nav {
  width: 210px;
  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
.flex-item {
  flex: 1;
}
</style>
