export const department = ['部门', '技术部', '产品部', '市场部', '运营部']
export const level = ['职级', '1级', '2级', '3级', '4级', '5级']
