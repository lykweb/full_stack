export const GET_EMPLOYEE_URL = '/api/employee/getEmployee.action';
