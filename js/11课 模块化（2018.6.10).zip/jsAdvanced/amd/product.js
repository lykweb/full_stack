define([],function(){
    console.log('product模块');
})