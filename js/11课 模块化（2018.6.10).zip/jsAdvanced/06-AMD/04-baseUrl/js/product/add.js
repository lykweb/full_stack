define([],function(){

    return function(){

        console.log('商品增加的功能');
    }
})