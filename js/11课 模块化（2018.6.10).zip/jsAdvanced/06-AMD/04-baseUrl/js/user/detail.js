define([],function(){
    var age=18;
    return function(){
        console.log('用户详细信息');
        return age;
    }
})