define([],function(){
    
    return {
        init(){
            console.log('商品模块初始化');
        }
    }
})