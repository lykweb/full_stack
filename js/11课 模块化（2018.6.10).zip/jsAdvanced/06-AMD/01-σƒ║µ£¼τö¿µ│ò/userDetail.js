define([],function(){
    console.log('用户详细信息模块');
})