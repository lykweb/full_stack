define([],function(){
    console.log('购物车模块详细信息');
})