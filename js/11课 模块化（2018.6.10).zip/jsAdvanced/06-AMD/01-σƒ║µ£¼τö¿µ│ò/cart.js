define(["cartDetail"],function(){
    console.log('购物车模块');

    //需要在cart模块内部调用cartDetail模块？
    //-->需要cart模块内部引用cartDetail的路径
})