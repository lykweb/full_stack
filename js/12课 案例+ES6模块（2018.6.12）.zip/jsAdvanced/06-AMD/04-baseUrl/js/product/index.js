define(["product/add"],function(productAdd){

    return function(){

        console.log('商品初始化');

        productAdd();
    }
})