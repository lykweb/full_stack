define(["userDetail"],function(){
    console.log('用户模块');
})