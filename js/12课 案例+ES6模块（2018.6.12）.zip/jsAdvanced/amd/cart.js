define([],function(){
    console.log('cart模块');
})