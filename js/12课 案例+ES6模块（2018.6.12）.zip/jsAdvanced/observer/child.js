define([""],function(){

    return function(){
        console.log('第一个子模块');
    }
})