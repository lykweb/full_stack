export const age = 18;
export const fn = ()=>{
    console.log('fn');
}

export default {
    name:"购物车"
}