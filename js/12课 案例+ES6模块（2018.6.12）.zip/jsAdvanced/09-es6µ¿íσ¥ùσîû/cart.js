var cart={
    name:"小电影",
    price:9.9
}

//暴露入口  =-->相当于模块的返回值
export default cart;